<template>
    <footer class="text-muted py-5 bg-dark">
  <div class="container">
    <p class="float-end mb-1">
      <a href="#">Back to top</a>
    </p>
    <p class="mb-1">All right reserved &copy; 2024 example.com</p>
    <p class="mb-0">About us <a href="/">Visit the homepage</a> or read our <a href="../getting-started/introduction/">Terms</a>.</p>
  </div>
</footer>
</template>