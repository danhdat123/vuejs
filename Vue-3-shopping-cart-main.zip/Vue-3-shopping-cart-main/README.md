How To Make A Vue 3 Shopping Cart
<br>Article: https://ahmedshaltout.com/vuejs/how-to-make-a-vue-3-shopping-cart/
<br>Video: https://youtu.be/AssWYh6ka0I
